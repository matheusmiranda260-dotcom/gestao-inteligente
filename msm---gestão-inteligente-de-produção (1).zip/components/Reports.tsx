
import React, { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, Sector } from 'recharts';
import type { Page, StockItem, ProductionRecord, MaterialType } from '../types';
import { ArrowLeftIcon } from './icons';

interface ReportsProps {
  stock: StockItem[];
  trefilaProduction: ProductionRecord[];
  trelicaProduction: ProductionRecord[];
  setPage: (page: Page) => void;
}

const Reports: React.FC<ReportsProps> = ({ stock, trefilaProduction, trelicaProduction, setPage }) => {
    const today = new Date();
    const thirtyDaysAgo = new Date(new Date().setDate(today.getDate() - 30));

    const [startDate, setStartDate] = useState(thirtyDaysAgo.toISOString().split('T')[0]);
    const [endDate, setEndDate] = useState(today.toISOString().split('T')[0]);

    const filteredProduction = useMemo(() => {
        const start = new Date(startDate);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999); 
        
        const filterByDate = (p: ProductionRecord) => {
            const pDate = new Date(p.date);
            return pDate >= start && pDate <= end;
        };

        return {
            trefila: trefilaProduction.filter(filterByDate),
            trelica: trelicaProduction.filter(filterByDate),
        };
    }, [trefilaProduction, trelicaProduction, startDate, endDate]);


    const totalStock = useMemo(() => stock.reduce((sum, item) => sum + item.remainingQuantity, 0), [stock]);
    
    const productionByMachineData = useMemo(() => {
        const trefilaTotal = filteredProduction.trefila.reduce((sum, p) => sum + p.producedWeight, 0);
        const trelicaTotal = filteredProduction.trelica.reduce((sum, p) => sum + p.producedWeight, 0);
        return [
            { name: 'Trefila', Produção: trefilaTotal },
            { name: 'Treliça', Produção: trelicaTotal },
        ];
    }, [filteredProduction]);

    const stockBySupplierData = useMemo(() => {
        const supplierMap = new Map<string, number>();
        stock.forEach(item => {
            if (item.remainingQuantity > 0) {
              supplierMap.set(item.supplier, (supplierMap.get(item.supplier) || 0) + item.remainingQuantity);
            }
        });
        return Array.from(supplierMap.entries()).map(([name, value]) => ({ name, value }));
    }, [stock]);
    
    const stockByMaterialData = useMemo(() => {
        const materialMap = new Map<MaterialType, number>();
        stock.forEach(item => {
            if (item.remainingQuantity > 0) {
              materialMap.set(item.materialType, (materialMap.get(item.materialType) || 0) + item.remainingQuantity);
            }
        });
        return Array.from(materialMap.entries()).map(([name, value]) => ({ name, value }));
    }, [stock]);

    const COLORS = ['#334155', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

    return (
        <div className="p-4 sm:p-6 md:p-8">
            <header className="flex items-center mb-6">
                <button onClick={() => setPage('menu')} className="mr-4 p-2 rounded-full hover:bg-slate-200 transition">
                    <ArrowLeftIcon className="h-6 w-6 text-slate-700" />
                </button>
                <h1 className="text-3xl font-bold text-slate-800">Relatórios e Indicadores</h1>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white p-6 rounded-xl shadow-sm">
                    <h3 className="text-slate-500 font-medium">Estoque Total Atual</h3>
                    <p className="text-3xl font-bold text-slate-800">{totalStock.toFixed(2)} kg</p>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm">
                    <h3 className="text-slate-500 font-medium">Produção Trefila (período)</h3>
                    <p className="text-3xl font-bold text-emerald-600">{productionByMachineData[0].Produção.toFixed(2)} kg</p>
                </div>
                 <div className="bg-white p-6 rounded-xl shadow-sm">
                    <h3 className="text-slate-500 font-medium">Produção Treliça (período)</h3>
                    <p className="text-3xl font-bold text-amber-600">{productionByMachineData[1].Produção.toFixed(2)} kg</p>
                </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm mb-8">
                <h2 className="text-xl font-semibold text-slate-700 mb-4">Filtro por Período</h2>
                <div className="flex items-center gap-4">
                    <div>
                        <label htmlFor="startDate" className="block text-sm font-medium text-slate-700">Data Inicial</label>
                        <input type="date" id="startDate" value={startDate} onChange={e => setStartDate(e.target.value)} className="mt-1 p-2 border border-slate-300 rounded" />
                    </div>
                    <div>
                        <label htmlFor="endDate" className="block text-sm font-medium text-slate-700">Data Final</label>
                        <input type="date" id="endDate" value={endDate} onChange={e => setEndDate(e.target.value)} className="mt-1 p-2 border border-slate-300 rounded" />
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <div className="bg-white p-6 rounded-xl shadow-sm">
                    <h2 className="text-xl font-semibold text-slate-700 mb-4">Produção por Máquina</h2>
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={productionByMachineData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip formatter={(value: number) => `${value.toFixed(2)} kg`} />
                            <Legend />
                            <Bar dataKey="Produção" fill="#334155" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-sm">
                    <h2 className="text-xl font-semibold text-slate-700 mb-4">Estoque por Fornecedor</h2>
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie
                                data={stockBySupplierData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="value"
                                nameKey="name"
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                                {stockBySupplierData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip formatter={(value: number) => `${value.toFixed(2)} kg`} />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                 <div className="bg-white p-6 rounded-xl shadow-sm">
                    <h2 className="text-xl font-semibold text-slate-700 mb-4">Estoque por Material</h2>
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie
                                data={stockByMaterialData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="value"
                                nameKey="name"
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                                {stockByMaterialData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip formatter={(value: number) => `${value.toFixed(2)} kg`} />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    );
};

export default Reports;