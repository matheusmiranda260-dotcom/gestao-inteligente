import React, { useState, useEffect, useMemo } from 'react';
import type { Page, User, StockItem, ConferenceData, ProductionOrderData, TransferRecord, Bitola, MachineType, PartsRequest, ShiftReport, ProductionRecord, TransferredLotInfo, ProcessedLot, DowntimeEvent, OperatorLog, TrelicaSelectedLots, WeighedPackage, FinishedProductItem, Ponta, PontaItem, FinishedGoodsTransferRecord, TransferredFinishedGoodInfo, Message } from './types';
import Login from './components/Login';
import MainMenu from './components/MainMenu';
import StockControl from './components/StockControl';
import MachineControl, { MachineSelection } from './components/MachineControl';
import ProductionOrder from './components/ProductionOrder';
import ProductionOrderTrelica from './components/ProductionOrderTrelica';
import Reports from './components/Reports';
import UserManagement from './components/UserManagement';
import Notification from './components/Notification';
import ProductionDashboard from './components/ProductionDashboard';
import { trelicaModels } from './components/ProductionOrderTrelica';
import FinishedGoods from './components/FinishedGoods';

const useStickyState = <T,>(defaultValue: T, key: string): [T, React.Dispatch<React.SetStateAction<T>>] => {
  const [value, setValue] = useState<T>(() => {
    try {
      const stickyValue = window.localStorage.getItem(key);
      return stickyValue !== null
        ? JSON.parse(stickyValue)
        : defaultValue;
    } catch {
      return defaultValue;
    }
  });

  useEffect(() => {
    window.localStorage.setItem(key, JSON.stringify(value));
  }, [key, value]);

  return [value, setValue];
};

const generateId = (prefix: string) => `${prefix.toUpperCase()}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

// Mock Data
const INITIAL_USERS: User[] = [
  { id: 'user-gestor', username: 'gestor', password: '070223', role: 'gestor' },
  { 
    id: 'user-adrian', 
    username: 'adrian', 
    password: '1234', 
    role: 'user', 
    permissions: { trelica: true } 
  },
  { 
    id: 'user-andrius', 
    username: 'andrius', 
    password: '1234', 
    role: 'user', 
    permissions: { trefila: true }
  },
];

const App: React.FC = () => {
  const [page, setPage] = useState<Page>('login');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const [users, setUsers] = useStickyState<User[]>(INITIAL_USERS, 'msm-users');
  const [stock, setStock] = useStickyState<StockItem[]>([], 'msm-stock');
  const [conferences, setConferences] = useStickyState<ConferenceData[]>([], 'msm-conferences');
  const [transfers, setTransfers] = useStickyState<TransferRecord[]>([], 'msm-transfers');
  const [productionOrders, setProductionOrders] = useStickyState<ProductionOrderData[]>([], 'msm-production-orders');
  const [finishedGoods, setFinishedGoods] = useStickyState<FinishedProductItem[]>([], 'msm-finished-goods');
  const [pontasStock, setPontasStock] = useStickyState<PontaItem[]>([], 'msm-pontas-stock');
  const [finishedGoodsTransfers, setFinishedGoodsTransfers] = useStickyState<FinishedGoodsTransferRecord[]>([], 'msm-finished-goods-transfers');
  const [partsRequests, setPartsRequests] = useStickyState<PartsRequest[]>([], 'msm-parts-requests');
  const [shiftReports, setShiftReports] = useStickyState<ShiftReport[]>([], 'msm-shift-reports');
  const [trefilaProduction, setTrefilaProduction] = useStickyState<ProductionRecord[]>([], 'msm-trefila-production');
  const [trelicaProduction, setTrelicaProduction] = useStickyState<ProductionRecord[]>([], 'msm-trelica-production');
  const [messages, setMessages] = useStickyState<Message[]>([], 'msm-messages');
  
  const showNotification = (message: string, type: 'success' | 'error') => {
    setNotification({ message, type });
  };
  
  const handleLogin = (username: string, password: string): void => {
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
      setCurrentUser(user);
      setPage('menu');
    } else {
      showNotification('Usuário ou senha inválidos.', 'error');
    }
  };

  const handleLogout = (): void => {
    setCurrentUser(null);
    setPage('login');
  };
  
  // Messaging System
  const addMessage = (messageText: string, productionOrderId: string, machine: MachineType) => {
    if (!currentUser) return;
    const newMessage: Message = {
      id: generateId('msg'),
      timestamp: new Date().toISOString(),
      productionOrderId,
      machine,
      senderId: currentUser.id,
      senderUsername: currentUser.username,
      message: messageText,
      isRead: false,
    };
    setMessages(prev => [...prev, newMessage].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()));
  };

  const markAllMessagesAsRead = () => {
    setMessages(prev => prev.map(m => ({ ...m, isRead: true })));
  };

  // User Management
  const addUser = (data: { username: string; password: string; permissions: Partial<Record<Page, boolean>> }) => {
    const newUser: User = {
        id: generateId('user'),
        username: data.username,
        password: data.password,
        role: 'user',
        permissions: data.permissions,
    };
    setUsers(prev => [...prev, newUser]);
    showNotification('Usuário adicionado com sucesso!', 'success');
  };

  const updateUser = (userId: string, data: Partial<User>) => {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...data } : u));
    showNotification('Usuário atualizado com sucesso!', 'success');
  };

  const deleteUser = (userId: string) => {
    setUsers(prev => prev.filter(u => u.id !== userId));
    showNotification('Usuário removido com sucesso!', 'success');
  };
  
  // Stock Control
  const addConference = (data: ConferenceData) => {
    const newStockItems: StockItem[] = data.lots.map(lot => ({
      id: generateId('stock'),
      entryDate: data.entryDate,
      supplier: data.supplier,
      nfe: data.nfe,
      conferenceNumber: data.conferenceNumber,
      internalLot: lot.internalLot,
      supplierLot: lot.supplierLot,
      runNumber: lot.runNumber,
      materialType: lot.materialType,
      bitola: lot.bitola,
      labelWeight: lot.labelWeight,
      initialQuantity: lot.scaleWeight,
      remainingQuantity: lot.scaleWeight,
      status: 'Disponível',
      history: [{
        type: 'Entrada em Estoque',
        date: new Date().toISOString(),
        details: {
          'Nº Conferência': data.conferenceNumber,
          'Peso Registrado': `${lot.scaleWeight.toFixed(2)} kg`,
        }
      }]
    }));
    setStock(prev => [...prev, ...newStockItems]);
    setConferences(prev => [...prev, data]);
    showNotification('Conferência adicionada com sucesso!', 'success');
  };

  const updateStockItem = (updatedItem: StockItem) => {
    setStock(prev => prev.map(item => item.id === updatedItem.id ? updatedItem : item));
    showNotification('Lote atualizado com sucesso!', 'success');
  };

  const deleteStockItem = (id: string) => {
    setStock(prev => prev.filter(item => item.id !== id));
    showNotification('Lote removido com sucesso!', 'success');
  };

  const createTransfer = (destinationSector: string, lotsToTransfer: Map<string, number>): TransferRecord | null => {
    if (!currentUser) return null;

    const transferredLotsInfo: TransferredLotInfo[] = [];
    const newStock = stock.map(item => {
        if (lotsToTransfer.has(item.id)) {
            const transferQty = lotsToTransfer.get(item.id)!;
            if (transferQty > item.remainingQuantity || transferQty <= 0) return item;
            
            const newItem = { ...item };
            const remaining = newItem.remainingQuantity - transferQty;
            newItem.remainingQuantity = remaining;
            if (remaining <= 0) {
                newItem.status = 'Transferido';
            }
            
            newItem.history = [...(newItem.history || []), {
                type: `Transferência para ${destinationSector}`,
                date: new Date().toISOString(),
                details: {
                    'Quantidade Transferida': `${transferQty.toFixed(2)} kg`,
                    'Operador': currentUser.username,
                }
            }];
            
            transferredLotsInfo.push({
                lotId: item.id,
                internalLot: item.internalLot,
                materialType: item.materialType,
                bitola: item.bitola,
                transferredQuantity: transferQty,
            });
            return newItem;
        }
        return item;
    });

    if (transferredLotsInfo.length === 0) {
        showNotification('Nenhuma quantidade válida para transferir.', 'error');
        return null;
    }

    const newTransferRecord: TransferRecord = {
        id: generateId('transf-mp'),
        date: new Date().toISOString(),
        operator: currentUser.username,
        destinationSector,
        transferredLots: transferredLotsInfo,
    };

    setStock(newStock);
    setTransfers(prev => [...prev, newTransferRecord]);
    showNotification('Transferência realizada com sucesso!', 'success');
    return newTransferRecord;
  };
  
    const createFinishedGoodsTransfer = (data: { destinationSector: string; otherDestination?: string; items: Map<string, number> }): FinishedGoodsTransferRecord | null => {
        if (!currentUser) return null;

        const transferredItems: TransferredFinishedGoodInfo[] = [];

        setFinishedGoods(prevGoods => {
            const newGoods = [...prevGoods];
            data.items.forEach((transferQty, itemId) => {
                const itemIndex = newGoods.findIndex(item => item.id === itemId);
                if (itemIndex !== -1) {
                    const originalItem = newGoods[itemIndex];
                    const weightPerPiece = originalItem.totalWeight / originalItem.quantity;
                    const transferredWeight = weightPerPiece * transferQty;

                    transferredItems.push({
                        productId: originalItem.id,
                        productType: originalItem.productType,
                        model: originalItem.model,
                        size: originalItem.size,
                        transferredQuantity: transferQty,
                        totalWeight: transferredWeight,
                    });

                    const newQuantity = originalItem.quantity - transferQty;
                    if (newQuantity > 0) {
                        newGoods[itemIndex] = {
                            ...originalItem,
                            quantity: newQuantity,
                            totalWeight: originalItem.totalWeight - transferredWeight,
                        };
                    } else {
                        newGoods[itemIndex] = {
                            ...originalItem,
                            quantity: 0,
                            totalWeight: 0,
                            status: 'Transferido',
                        };
                    }
                }
            });
            return newGoods;
        });

        setPontasStock(prevPontas => {
            const newPontas = [...prevPontas];
            data.items.forEach((transferQty, itemId) => {
                const itemIndex = newPontas.findIndex(item => item.id === itemId);
                if (itemIndex !== -1) {
                    const originalItem = newPontas[itemIndex];
                    const weightPerPiece = originalItem.totalWeight / originalItem.quantity;
                    const transferredWeight = weightPerPiece * transferQty;
                    
                    transferredItems.push({
                        productId: originalItem.id,
                        productType: originalItem.productType,
                        model: originalItem.model,
                        size: originalItem.size,
                        transferredQuantity: transferQty,
                        totalWeight: transferredWeight,
                    });

                    const newQuantity = originalItem.quantity - transferQty;
                    if (newQuantity > 0) {
                        newPontas[itemIndex] = {
                            ...originalItem,
                            quantity: newQuantity,
                            totalWeight: originalItem.totalWeight - transferredWeight,
                        };
                    } else {
                        newPontas[itemIndex] = {
                            ...originalItem,
                            quantity: 0,
                            totalWeight: 0,
                            status: 'Transferido',
                        };
                    }
                }
            });
            return newPontas;
        });

        if (transferredItems.length === 0) {
            showNotification('Nenhum item válido para transferência.', 'error');
            return null;
        }

        const newTransferRecord: FinishedGoodsTransferRecord = {
            id: generateId('transf-pa'),
            date: new Date().toISOString(),
            operator: currentUser.username,
            destinationSector: data.destinationSector,
            otherDestination: data.otherDestination,
            transferredItems,
        };

        setFinishedGoodsTransfers(prev => [newTransferRecord, ...prev].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        showNotification('Transferência de produto acabado realizada com sucesso!', 'success');
        return newTransferRecord;
    };
  
  // Production Order
  const addProductionOrder = (order: Omit<ProductionOrderData, 'id' | 'status' | 'creationDate'>) => {
    const newOrder: ProductionOrderData = {
        ...order,
        id: generateId('op'),
        status: 'pending',
        creationDate: new Date().toISOString(),
    };
    setProductionOrders(prev => [...prev, newOrder]);
    
    const lotIds = Array.isArray(order.selectedLotIds) ? order.selectedLotIds : Object.values(order.selectedLotIds);
    const now = new Date().toISOString();

    setStock(prevStock => 
        prevStock.map(s => {
            if (lotIds.includes(s.id)) {
                const newStatus: StockItem['status'] = order.machine === 'Treliça' ? 'Em Produção - Treliça' : 'Em Produção';
                const existingIds = s.productionOrderIds || [];
                return {
                    ...s,
                    status: newStatus,
                    productionOrderIds: [...existingIds, newOrder.id],
                    history: [...(s.history || []), {
                        type: 'Alocado para Ordem de Produção',
                        date: now,
                        details: { 'Nº Ordem': order.orderNumber }
                    }]
                };
            }
            return s;
        })
    );
    showNotification(`Ordem de produção "${order.orderNumber}" criada com sucesso.`, 'success');
};

  const updateProductionOrder = (orderId: string, data: { orderNumber?: string; targetBitola?: Bitola }) => {
    setProductionOrders(prev => prev.map(o => o.id === orderId ? { ...o, ...data } : o));
    showNotification('Ordem de produção atualizada.', 'success');
  };
  
  const deleteProductionOrder = (orderId: string) => {
    const orderToDelete = productionOrders.find(o => o.id === orderId);
    if (!orderToDelete) return;
    
    const lotIds = Array.isArray(orderToDelete.selectedLotIds) ? orderToDelete.selectedLotIds : Object.values(orderToDelete.selectedLotIds);

    const updatedStock = stock.map(s => {
      if (lotIds.includes(s.id)) {
        const newIds = (s.productionOrderIds || []).filter(id => id !== orderId);
        return { 
            ...s, 
            status: newIds.length === 0 ? 'Disponível' : s.status,
            productionOrderIds: newIds.length > 0 ? newIds : undefined,
        };
      }
      return s;
    });
    setStock(updatedStock);
    setProductionOrders(prev => prev.filter(o => o.id !== orderId));
    showNotification('Ordem de produção excluída.', 'success');
  };
  
  // Machine Control Trefila
  const startProductionOrder = (orderId: string) => {
    if (!currentUser) return;
    const now = new Date().toISOString();
    
    setProductionOrders(prevOrders => {
        const newOrders = [...prevOrders];
        const newOrderIndex = newOrders.findIndex(o => o.id === orderId);
        if (newOrderIndex === -1) return prevOrders;

        const orderToStartData = newOrders[newOrderIndex];
        const newOrderMachine = orderToStartData.machine;

        // Find and close any existing open shift for this user/machine
        // An open shift could be in an 'in_progress' order or a recently 'completed' one.
        const openShiftOrderIndex = newOrders.findIndex(o => 
            o.machine === newOrderMachine &&
            (o.operatorLogs || []).some(log => log.operator === currentUser.username && !log.endTime)
        );

        if (openShiftOrderIndex !== -1) {
            const openShiftOrder = { ...newOrders[openShiftOrderIndex] };
            openShiftOrder.operatorLogs = (openShiftOrder.operatorLogs || []).map(log => 
                (log.operator === currentUser.username && !log.endTime) ? { ...log, endTime: now } : log
            );
            newOrders[openShiftOrderIndex] = openShiftOrder;
        }

        // Start the new order
        const orderToStart = { ...orderToStartData };
        orderToStart.status = 'in_progress';
        orderToStart.startTime = now;
        orderToStart.downtimeEvents = [...(orderToStart.downtimeEvents || []), { 
            stopTime: now, 
            resumeTime: null, 
            reason: 'Aguardando Início da Produção' 
        }];
        
        // If we closed an old shift, we open a new one automatically to continue the session
        if (openShiftOrderIndex !== -1) {
            orderToStart.operatorLogs = [...(orderToStart.operatorLogs || []), {
                operator: currentUser.username,
                startTime: now,
                endTime: null
            }];
        }
        
        newOrders[newOrderIndex] = orderToStart;
        return newOrders;
    });
  };
  
  const startOperatorShift = (orderId: string) => {
    if (!currentUser) return;
    const now = new Date().toISOString();
    setProductionOrders(prev => prev.map(o => {
        if (o.id === orderId) {
            const updatedOrder: ProductionOrderData = {
                ...o,
                operatorLogs: [...(o.operatorLogs || []), { operator: currentUser.username, startTime: now, endTime: null }],
            };

            // For Treliça, automatically resume production when shift starts
            if (updatedOrder.machine === 'Treliça') {
                const newEvents = [...(updatedOrder.downtimeEvents || [])];
                let lastEventIndex = -1;
                for (let i = newEvents.length - 1; i >= 0; i--) {
                    if (!newEvents[i].resumeTime) {
                        lastEventIndex = i;
                        break;
                    }
                }
                if (lastEventIndex !== -1) {
                    newEvents[lastEventIndex].resumeTime = now;
                }
                updatedOrder.downtimeEvents = newEvents;
            }

            return updatedOrder;
        }
        return o;
    }));
  };
  
  const generateShiftReport = (order: ProductionOrderData, operatorLog: OperatorLog) => {
        if (!operatorLog.endTime) return;
        const shiftStart = new Date(operatorLog.startTime);
        const shiftEnd = new Date(operatorLog.endTime);
        
        const shiftDowntimeEvents = (order.downtimeEvents || []).filter(event => {
            const stop = new Date(event.stopTime);
            return stop >= shiftStart && stop < shiftEnd;
        });
        
        const shiftProcessedLots = (order.processedLots || []).filter(lot => {
            const end = new Date(lot.endTime);
            return end >= shiftStart && end < shiftEnd;
        });

        const totalProducedWeight = shiftProcessedLots.reduce((sum, lot) => sum + (lot.finalWeight || 0), 0);
        
        const totalScrapWeight = 0; // Simplified
        const scrapPercentage = totalProducedWeight > 0 ? (totalScrapWeight / (totalProducedWeight + totalScrapWeight)) * 100 : 0;
        
        const weightKg = totalProducedWeight;
        const bitolaMm = parseFloat(order.targetBitola);
        const steelDensityKgPerM3 = 7850;
        const radiusM = (bitolaMm / 1000) / 2;
        const areaM2 = Math.PI * Math.pow(radiusM, 2);
        const volumeM3 = weightKg / steelDensityKgPerM3;
        const totalProducedMeters = volumeM3 / areaM2;

        const report: ShiftReport = {
            id: generateId('shift'),
            date: shiftEnd.toISOString(),
            operator: operatorLog.operator,
            machine: order.machine,
            productionOrderId: order.id,
            orderNumber: order.orderNumber,
            targetBitola: order.targetBitola,
            trelicaModel: order.trelicaModel,
            tamanho: order.tamanho,
            quantityToProduce: order.quantityToProduce,
            shiftStartTime: operatorLog.startTime,
            shiftEndTime: operatorLog.endTime,
            processedLots: shiftProcessedLots,
            downtimeEvents: shiftDowntimeEvents,
            totalProducedWeight,
            totalProducedMeters,
            totalScrapWeight,
            scrapPercentage,
        };

        setShiftReports(prev => [...prev, report]);
  };


  const endOperatorShift = (orderId: string) => {
      if (!currentUser) return;
      let order: ProductionOrderData | undefined;
      let operatorLog: OperatorLog | undefined;
      setProductionOrders(prev => prev.map(o => {
          if (o.id === orderId) {
              order = o;
              const newLogs = [...(o.operatorLogs || [])];
              let lastLogIndex = -1;
              for (let i = newLogs.length - 1; i >= 0; i--) {
                if (newLogs[i].operator === currentUser?.username && !newLogs[i].endTime) {
                    lastLogIndex = i;
                    break;
                }
              }
              if (lastLogIndex !== -1) {
                  newLogs[lastLogIndex].endTime = new Date().toISOString();
                  operatorLog = newLogs[lastLogIndex];
              }
              return { ...o, operatorLogs: newLogs };
          }
          return o;
      }));

      if(order && operatorLog) {
          generateShiftReport(order, operatorLog);
      }
  };
  
  const logDowntime = (orderId: string, reason: string) => {
      const now = new Date().toISOString();
      setProductionOrders(prev => prev.map(o => {
          if (o.id === orderId) {
              const newEvents = [...(o.downtimeEvents || [])];
              let lastEventIndex = -1;
              for (let i = newEvents.length - 1; i >= 0; i--) {
                if (!newEvents[i].resumeTime) {
                    lastEventIndex = i;
                    break;
                }
              }
              if (lastEventIndex !== -1) {
                  newEvents[lastEventIndex].resumeTime = now;
              }
              newEvents.push({ stopTime: now, resumeTime: null, reason });
              return { ...o, downtimeEvents: newEvents };
          }
          return o;
      }));
  };
  
  const logResumeProduction = (orderId: string) => {
      const now = new Date().toISOString();
      setProductionOrders(prev => prev.map(o => {
          if (o.id === orderId) {
              const newEvents = [...(o.downtimeEvents || [])];
              let lastEventIndex = -1;
              for (let i = newEvents.length - 1; i >= 0; i--) {
                if (!newEvents[i].resumeTime) {
                    lastEventIndex = i;
                    break;
                }
              }
              if (lastEventIndex !== -1) {
                  newEvents[lastEventIndex].resumeTime = now;
              }
              if (!o.activeLotProcessing && o.machine === 'Trefila') {
                   newEvents.push({ stopTime: now, resumeTime: null, reason: 'Troca de Rolo / Preparação' });
              }
              return { ...o, downtimeEvents: newEvents };
          }
          return o;
      }));
  };
  
  const startLotProcessing = (orderId: string, lotId: string) => {
      const now = new Date().toISOString();
      setProductionOrders(prev => prev.map(o => {
          if (o.id === orderId) {
              const newEvents = [...(o.downtimeEvents || [])];
              let lastEventIndex = -1;
              for (let i = newEvents.length - 1; i >= 0; i--) {
                if (!newEvents[i].resumeTime) {
                    lastEventIndex = i;
                    break;
                }
              }
              if (lastEventIndex !== -1) {
                  newEvents[lastEventIndex].resumeTime = now;
              }
              return { 
                  ...o, 
                  activeLotProcessing: { lotId, startTime: now },
                  downtimeEvents: newEvents 
              };
          }
          return o;
      }));
  };
  
  const finishLotProcessing = (orderId: string, lotId: string) => {
      const now = new Date().toISOString();
      setProductionOrders(prev => prev.map(o => {
          if (o.id === orderId && o.activeLotProcessing?.lotId === lotId) {
              const processedLot: ProcessedLot = {
                  lotId,
                  finalWeight: null,
                  startTime: o.activeLotProcessing.startTime,
                  endTime: now,
              };
              const newDowntime: DowntimeEvent = {
                  stopTime: now,
                  resumeTime: null,
                  reason: 'Troca de Rolo / Preparação'
              };
              return { 
                  ...o, 
                  activeLotProcessing: undefined, 
                  processedLots: [...(o.processedLots || []), processedLot],
                  downtimeEvents: [...(o.downtimeEvents || []), newDowntime]
              };
          }
          return o;
      }));
  };
  
const completeProduction = (orderId: string, finalData: { actualProducedQuantity?: number; scrapWeight?: number; pontas?: Ponta[] }) => {
    const now = new Date().toISOString();

    setProductionOrders(prevOrders => {
        const orderToComplete = prevOrders.find(o => o.id === orderId);
        if (!orderToComplete || orderToComplete.status === 'completed') {
            return prevOrders; // No change if order not found or already completed
        }

        let completedOrder: ProductionOrderData;

        // Common completion logic
        const newEvents = [...(orderToComplete.downtimeEvents || [])];
        let lastEventIndex = -1;
        for (let i = newEvents.length - 1; i >= 0; i--) {
            if (!newEvents[i].resumeTime) {
                lastEventIndex = i;
                break;
            }
        }
        if (lastEventIndex !== -1) {
            newEvents[lastEventIndex].resumeTime = now;
        }

        if (orderToComplete.machine === 'Trefila') {
            const actualProducedWeight = (orderToComplete.processedLots || []).reduce((sum, lot) => sum + (lot.finalWeight || 0), 0);
            const totalInputWeight = (orderToComplete.processedLots || []).reduce((sum, processedLot) => {
                const originalLot = stock.find(s => s.id === processedLot.lotId);
                return sum + (originalLot?.labelWeight || 0);
            }, 0);
            const calculatedScrapWeight = totalInputWeight - actualProducedWeight;

            completedOrder = {
                ...orderToComplete,
                status: 'completed',
                endTime: now,
                downtimeEvents: newEvents,
                actualProducedWeight,
                scrapWeight: calculatedScrapWeight >= 0 ? calculatedScrapWeight : 0,
            };
        } else { // Treliça
            const actualProducedWeight = (orderToComplete.weighedPackages || []).reduce((sum, pkg) => sum + pkg.weight, 0);
            completedOrder = {
                ...orderToComplete,
                status: 'completed',
                endTime: now,
                downtimeEvents: newEvents,
                actualProducedQuantity: finalData.actualProducedQuantity,
                pontas: finalData.pontas,
                actualProducedWeight,
            };
        }

        const updatedOrders = prevOrders.map(o => o.id === orderId ? completedOrder : o);

        // --- Side Effects using fresh data ---

        // 1. Update Stock State
        if (completedOrder.machine === 'Trefila') {
            setStock(prevStock => prevStock.map(item => {
                const processedLotData = (completedOrder.processedLots || []).find(pLot => pLot.lotId === item.id);
                if (processedLotData) {
                    const finalWeight = processedLotData.finalWeight || 0;
                    return {
                        ...item,
                        materialType: 'CA-60', bitola: completedOrder.targetBitola, labelWeight: finalWeight,
                        initialQuantity: finalWeight, remainingQuantity: finalWeight, status: 'Disponível', productionOrderIds: undefined,
                        history: [...(item.history || []), {
                            type: 'Transformado em CA-60', date: now,
                            details: { 'Ordem': completedOrder.orderNumber, 'Bitola Original': item.bitola, 'Bitola Final': completedOrder.targetBitola, 'Peso Final (kg)': finalWeight.toFixed(2) }
                        }]
                    };
                }
                return item;
            }));
        } else if (completedOrder.machine === 'Treliça') {
            const modelInfo = trelicaModels.find(m => m.modelo === completedOrder.trelicaModel && m.tamanho === completedOrder.tamanho);
            if (modelInfo) {
                const parse = (s: string) => parseFloat(s.replace(',', '.'));
                const fullPiecesQty = completedOrder.actualProducedQuantity || 0;

                const consumedFull = {
                    superior: parse(modelInfo.pesoSuperior) * fullPiecesQty,
                    inferior: parse(modelInfo.pesoInferior) * fullPiecesQty,
                    senozoide: parse(modelInfo.pesoSenozoide) * fullPiecesQty,
                };
                
                const consumedPontas = { superior: 0, inferior: 0, senozoide: 0 };
                const modelTamanho = parse(modelInfo.tamanho);

                if (modelTamanho > 0) {
                    (completedOrder.pontas || []).forEach(ponta => {
                        const ratio = ponta.size / modelTamanho;
                        consumedPontas.superior += parse(modelInfo.pesoSuperior) * ponta.quantity * ratio;
                        consumedPontas.inferior += parse(modelInfo.pesoInferior) * ponta.quantity * ratio;
                        consumedPontas.senozoide += parse(modelInfo.pesoSenozoide) * ponta.quantity * ratio;
                    });
                }

                const totalConsumed = {
                    superior: consumedFull.superior + consumedPontas.superior,
                    inferior: consumedFull.inferior + consumedPontas.inferior,
                    senozoide: consumedFull.senozoide + consumedPontas.senozoide,
                };

                const lots = completedOrder.selectedLotIds as TrelicaSelectedLots;
                const consumedMap = new Map<string, number>();
                consumedMap.set(lots.superior, (consumedMap.get(lots.superior) || 0) + totalConsumed.superior);
                consumedMap.set(lots.inferior1, (consumedMap.get(lots.inferior1) || 0) + totalConsumed.inferior / 2);
                consumedMap.set(lots.inferior2, (consumedMap.get(lots.inferior2) || 0) + totalConsumed.inferior / 2);
                consumedMap.set(lots.senozoide1, (consumedMap.get(lots.senozoide1) || 0) + totalConsumed.senozoide / 2);
                consumedMap.set(lots.senozoide2, (consumedMap.get(lots.senozoide2) || 0) + totalConsumed.senozoide / 2);
                
                setStock(prevStock => prevStock.map(stockItem => {
                    if (!consumedMap.has(stockItem.id)) return stockItem;

                    const consumedQty = consumedMap.get(stockItem.id)!;
                    const newRemainingQty = Math.max(0, stockItem.remainingQuantity - consumedQty);
                    const remainingOrderIds = (stockItem.productionOrderIds || []).filter(id => id !== orderId);
                    const hasOtherActiveOrders = remainingOrderIds.some(otherId =>
                        updatedOrders.some(o => o.id === otherId && (o.status === 'pending' || o.status === 'in_progress'))
                    );

                    return {
                        ...stockItem,
                        remainingQuantity: newRemainingQty,
                        labelWeight: newRemainingQty,
                        productionOrderIds: remainingOrderIds.length > 0 ? remainingOrderIds : undefined,
                        status: hasOtherActiveOrders ? stockItem.status : (newRemainingQty > 0.01 ? 'Disponível - Suporte Treliça' : 'Transferido'),
                        history: [...(stockItem.history || []), {
                            type: 'Consumido na Produção de Treliça', date: now,
                            details: { 'Ordem': completedOrder.orderNumber, 'Qtd Consumida': consumedQty.toFixed(2) }
                        }]
                    };
                }));

                const newPontaItems: PontaItem[] = (completedOrder.pontas || []).map(ponta => ({
                    id: generateId('ponta'),
                    productionDate: now,
                    productionOrderId: completedOrder.id,
                    orderNumber: completedOrder.orderNumber,
                    productType: 'Ponta de Treliça',
                    model: completedOrder.trelicaModel!,
                    size: `${ponta.size}`,
                    quantity: ponta.quantity,
                    totalWeight: ponta.totalWeight,
                    status: 'Disponível',
                }));
                
                if (newPontaItems.length > 0) {
                    setPontasStock(prev => [...prev, ...newPontaItems].sort((a,b) => new Date(b.productionDate).getTime() - new Date(a.productionDate).getTime()));
                }
            }
        }
        
        // 2. Update Finished Goods State (for full pieces)
        if (completedOrder.machine === 'Treliça' && completedOrder.actualProducedQuantity && completedOrder.actualProducedQuantity > 0) {
            const newFinishedProduct: FinishedProductItem = {
                id: generateId('fg'),
                productionDate: now,
                productionOrderId: completedOrder.id,
                orderNumber: completedOrder.orderNumber,
                productType: 'Treliça',
                model: completedOrder.trelicaModel!,
                size: completedOrder.tamanho!,
                quantity: completedOrder.actualProducedQuantity!,
                totalWeight: completedOrder.actualProducedWeight!,
                status: 'Disponível',
            };
            setFinishedGoods(prev => [...prev, newFinishedProduct].sort((a, b) => new Date(b.productionDate).getTime() - new Date(a.productionDate).getTime()));
        }

        // 3. Show Notification
        showNotification(`Ordem ${completedOrder.orderNumber} finalizada.`, 'success');

        return updatedOrders;
    });
};


  const recordLotWeight = (orderId: string, lotId: string, finalWeight: number) => {
    setProductionOrders(prev => prev.map(o => {
        if (o.id === orderId) {
            const newProcessedLots = (o.processedLots || []).map(p =>
                p.lotId === lotId ? { ...p, finalWeight } : p
            );
            return { ...o, processedLots: newProcessedLots };
        }
        return o;
    }));
  };
  
  const recordPackageWeight = (orderId: string, packageData: { packageNumber: number; quantity: number; weight: number; }) => {
    const now = new Date().toISOString();
    setProductionOrders(prev => prev.map(o => {
        if (o.id === orderId) {
            const newPackage: WeighedPackage = { ...packageData, timestamp: now };
            const existingPackages = o.weighedPackages || [];
            const otherPackages = existingPackages.filter(p => p.packageNumber !== packageData.packageNumber);
            return {
                ...o,
                weighedPackages: [...otherPackages, newPackage].sort((a,b) => a.packageNumber - b.packageNumber)
            };
        }
        return o;
    }));
    showNotification(`Peso do pacote #${packageData.packageNumber} registrado com sucesso.`, 'success');
  };
  
    const updateProducedQuantity = (orderId: string, quantity: number) => {
        setProductionOrders(prev => prev.map(o => {
            if (o.id === orderId) {
                return { ...o, actualProducedQuantity: quantity };
            }
            return o;
        }));
        showNotification('Contagem de peças atualizada.', 'success');
    };

  const addPartsRequest = (data: Omit<PartsRequest, 'id' | 'date' | 'operator' | 'status'>) => {
      if (!currentUser) return;
      const activeOrder = productionOrders.find(o => o.status === 'in_progress');
      if (!activeOrder) return;
      const newRequest: PartsRequest = {
          ...data,
          id: generateId('part'),
          date: new Date().toISOString(),
          operator: currentUser.username,
          status: 'Pendente',
          machine: activeOrder.machine,
          productionOrderId: activeOrder.id,
      };
      setPartsRequests(prev => [...prev, newRequest]);
      showNotification('Solicitação de peças enviada.', 'success');
  };

  const logPostProductionActivity = (activity: string) => {
    if (!currentUser) return;

    setProductionOrders(prevOrders => {
        const newOrders = [...prevOrders];
        let targetOrderIndex = -1;
        let latestEndTime = 0;

        newOrders.forEach((order, index) => {
            if (order.status === 'completed' && order.endTime) {
                const orderEndTime = new Date(order.endTime).getTime();
                const hasOpenLog = (order.operatorLogs || []).some(log => log.operator === currentUser.username && !log.endTime);

                if (hasOpenLog && orderEndTime > latestEndTime) {
                    targetOrderIndex = index;
                    latestEndTime = orderEndTime;
                }
            }
        });
        
        if (targetOrderIndex !== -1) {
            const targetOrder = { ...newOrders[targetOrderIndex] };
            
            const logsCopy = [...(targetOrder.operatorLogs || [])];
            let logIndex = -1;
            for(let i = logsCopy.length - 1; i >= 0; i--) {
                if(logsCopy[i].operator === currentUser.username && !logsCopy[i].endTime) {
                    logIndex = i;
                    break;
                }
            }
            
            if (logIndex !== -1) {
                const updatedLog = { ...logsCopy[logIndex] };
                if (!updatedLog.postProductionActivities) {
                    updatedLog.postProductionActivities = [];
                }
                updatedLog.postProductionActivities.push({
                    timestamp: new Date().toISOString(),
                    description: activity
                });
                
                logsCopy[logIndex] = updatedLog;
                targetOrder.operatorLogs = logsCopy;
                newOrders[targetOrderIndex] = targetOrder;
                
                showNotification('Atividade registrada com sucesso.', 'success');
                return newOrders;
            }
        }
        return prevOrders;
    });
  };
  
  // Machine Control Treliça
  const registerProduction = (machine: MachineType, producedWeight: number) => {
    const newRecord: ProductionRecord = {
      id: generateId('prod'),
      date: new Date().toISOString(),
      machine,
      producedWeight,
      consumedLots: [], // Simplified for this implementation
    };
    if (machine === 'Trefila') {
        setTrefilaProduction(prev => [...prev, newRecord]);
    } else {
        setTrelicaProduction(prev => [...prev, newRecord]);
    }
    showNotification(`Produção de ${producedWeight.toFixed(2)} kg registrada para ${machine}.`, 'success');
  };
  
  const renderPage = () => {
    const machineControlProps = {
        setPage, stock, currentUser, registerProduction, productionOrders, shiftReports, 
        startProductionOrder, startOperatorShift, endOperatorShift, logDowntime, 
        logResumeProduction, startLotProcessing, finishLotProcessing, recordLotWeight, 
        addPartsRequest, logPostProductionActivity, completeProduction, recordPackageWeight,
        updateProducedQuantity, messages, addMessage
    };

    switch (page) {
      case 'login':
        return <Login onLogin={handleLogin} error={notification?.type === 'error' ? notification.message : null} />;
      case 'menu':
        return <MainMenu setPage={setPage} onLogout={handleLogout} currentUser={currentUser} messages={messages} markAllMessagesAsRead={markAllMessagesAsRead} addMessage={addMessage} />;
      case 'stock':
        return <StockControl stock={stock} conferences={conferences} transfers={transfers} setPage={setPage} addConference={addConference} deleteStockItem={deleteStockItem} updateStockItem={updateStockItem} createTransfer={createTransfer} />;
      case 'trefila':
        return <MachineControl machineType="Trefila" {...machineControlProps} />;
      case 'trelica':
        return <MachineControl machineType="Treliça" {...machineControlProps} users={users} />;
      case 'machineSelection':
        return <MachineSelection setPage={setPage} />;
      case 'productionOrder':
        return <ProductionOrder setPage={setPage} stock={stock} productionOrders={productionOrders} addProductionOrder={addProductionOrder} showNotification={showNotification} updateProductionOrder={updateProductionOrder} deleteProductionOrder={deleteProductionOrder} />;
      case 'productionOrderTrelica':
        return <ProductionOrderTrelica setPage={setPage} stock={stock} productionOrders={productionOrders} addProductionOrder={addProductionOrder} showNotification={showNotification} updateProductionOrder={updateProductionOrder} deleteProductionOrder={deleteProductionOrder} />;
      case 'productionDashboard':
        return <ProductionDashboard setPage={setPage} productionOrders={productionOrders} stock={stock} currentUser={currentUser} />;
      case 'reports':
        return <Reports setPage={setPage} stock={stock} trefilaProduction={trefilaProduction} trelicaProduction={trelicaProduction} />;
      case 'userManagement':
        return <UserManagement users={users} addUser={addUser} updateUser={updateUser} deleteUser={deleteUser} setPage={setPage} />;
      case 'finishedGoods':
        return <FinishedGoods finishedGoods={finishedGoods} pontasStock={pontasStock} setPage={setPage} finishedGoodsTransfers={finishedGoodsTransfers} createFinishedGoodsTransfer={createFinishedGoodsTransfer} />;
      default:
        return <Login onLogin={handleLogin} error={null} />;
    }
  };

  return (
    <div className="bg-slate-100 min-h-screen">
      {notification && <Notification message={notification.message} type={notification.type} onClose={() => setNotification(null)} />}
      {renderPage()}
    </div>
  );
};

export default App;